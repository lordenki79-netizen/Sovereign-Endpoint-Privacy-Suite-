<#
.SYNOPSIS
    Sovereign Endpoint Baseline Deployer (v2.1 - Absolute Production Ready)
    Description: Automated zero-trust endpoint hardening, silent binary & tool acquisition,
                 balanced firewall lockdown, network/DNS enforcement, and environment cloning.
#>

# Ensure script runs with Administrator privileges
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[!] Elevating privileges to Administrator..." -ForegroundColor Yellow
    Start-Process powershell.exe -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs
    Exit
}

$ErrorActionPreference = "SilentlyContinue"

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " INITIATING SOVEREIGN BASELINE PROVISIONING ENGINE v2.1" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

# ======================================================================
# STEP 1: SILENT BINARY & TOOLING ACQUISITION VIA WINGET
# ======================================================================
Write-Host "[*] Step 1: Initializing package repository and deploying core tools..." -ForegroundColor Yellow

winget source update --force | Out-Null

$Tools = @(
    "Mozilla.Firefox",
    "WiresharkFoundation.Wireshark",
    "Insecure.Npcap",
    "Python.Python.3.11",
    "Git.Git"
)

foreach ($tool in$Tools) {
    Write-Host "    -> Deploying: $tool" -ForegroundColor DarkCyan
    winget install --id $tool --silent --accept-package-agreements --accept-source-agreements
}

$WorkspacePath = "C:\SovereignWorkspace"
if (!(Test-Path $WorkspacePath)) { New-Item -Path$WorkspacePath -ItemType Directory -Force | Out-Null }

Write-Host "[+] Core binaries and runtime environments deployed." -ForegroundColor Green


# ======================================================================
# STEP 2: NETWORK & DNS LOCKDOWN (QUAD9 ENFORCEMENT)
# ======================================================================
Write-Host "[*] Step 2: Enforcing Quad9 secure DNS and flushing routing tables..." -ForegroundColor Yellow

Start-Sleep -Seconds 3
# Updated to target physical adapters only and avoid VPN conflicts
$ActiveAdapters = Get-NetAdapter | Where-Object {$_.Status -eq 'Up' -and$_.InterfaceDescription -notmatch 'VPN|Virtual|Tunnel'}

foreach ($adapter in$ActiveAdapters) {
    Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses ("9.9.9.9", "149.112.112.112")
    Write-Host "    -> Configured DNS for adapter: $($adapter.Name)" -ForegroundColor DarkCyan
}

netsh winsock reset | Out-Null
netsh int ip reset | Out-Null
Clear-DnsClientCache

Write-Host "[+] Network perimeter locked to Quad9." -ForegroundColor Green


# ======================================================================
# STEP 3: BALANCED FIREWALL LOCKDOWN (ZERO DISRUPTION)
# ======================================================================
Write-Host "[*] Step 3: Applying balanced firewall baseline..." -ForegroundColor Yellow

Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled True
Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultInboundAction Block -DefaultOutboundAction Allow

$TelemetryIPs = @("134.170.30.202", "137.116.81.24", "204.79.197.200")
foreach ($ip in$TelemetryIPs) {
    New-NetFirewallRule -DisplayName "Block-Telemetry-$ip" -Direction Outbound -Action Block -RemoteAddress $ip -ErrorAction SilentlyContinue | Out-Null
}

Write-Host "[+] Firewall rules applied: Default-deny inbound, clean outbound." -ForegroundColor Green


# ======================================================================
# STEP 4: TELEMETRY & BACKGROUND SERVICE PURGE
# ======================================================================
Write-Host "[*] Step 4: Purging telemetry tasks and background bloat..." -ForegroundColor Yellow

$TelemetryTasks = @(
    "*CEIP*",
    "*Customer Experience*",
    "*Telemetry*",
    "*Microsoft Compatibility Appraiser*"
)

foreach ($taskPattern in$TelemetryTasks) {
    Get-ScheduledTask -TaskName $taskPattern | Disable-ScheduledTask -ErrorAction SilentlyContinue
}

$UnwantedServices = @("DiagTrack", "dmwappushservice", "WerSvc")
foreach ($svc in$UnwantedServices) {
    Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
    Set-Service -Name $svc -StartupType Disabled -ErrorAction SilentlyContinue
}

Write-Host "[+] Telemetry tasks and background services purged." -ForegroundColor Green


# ======================================================================
# STEP 5: REGISTRY HARDENING & POWERSHELL LOGGING
# ======================================================================
Write-Host "[*] Step 5: Applying registry security baselines..." -ForegroundColor Yellow

$PSLogPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging"
if (!(Test-Path $PSLogPath)) { New-Item -Path$PSLogPath -Force | Out-Null }
Set-ItemProperty -Path $PSLogPath -Name "EnableScriptBlockLogging" -Value 1

$CloudContentPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent"
if (!(Test-Path $CloudContentPath)) { New-Item -Path$CloudContentPath -Force | Out-Null }
Set-ItemProperty -Path $CloudContentPath -Name "DisableWindowsConsumerFeatures" -Value 1

Write-Host "[+] Registry hardened." -ForegroundColor Green


# ======================================================================
# EXECUTION COMPLETE
# ======================================================================
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " SOVEREIGN BASELINE DEPLOYMENT COMPLETE. SYSTEM IS LOCKED." -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan

$reboot = Read-Host "[?] Restart system now to finalize network and driver states? (Y/N)"
if ($reboot -eq 'Y' -or$reboot -eq 'y') {
    Restart-Computer -Force
}