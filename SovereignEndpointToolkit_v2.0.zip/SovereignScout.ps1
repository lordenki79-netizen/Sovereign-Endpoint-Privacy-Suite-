<#
.SYNOPSIS
    Sovereign Scout System Audit & Diagnostics (v2.0)
.DESCRIPTION
    Performs a read-only security posture assessment, capturing OS info,
    network configurations, DNS assignments, firewall profiles, and service states.
#>

[CmdletBinding()]
param()

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " INITIATING SOVEREIGN SCOUT SYSTEM AUDIT v2.0" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

# 1. System & OS Overview
Write-Host "[*] Gathering OS and hardware inventory..." -ForegroundColor Yellow
$OS = Get-CimInstance Win32_OperatingSystem
$Computer = Get-CimInstance Win32_ComputerSystem
Write-Host "    -> Hostname: $($Computer.Name)" -ForegroundColor DarkCyan
Write-Host "    -> OS Version: $($OS.Caption) ($($OS.Version))" -ForegroundColor DarkCyan
Write-Host "    -> Architecture: $($OS.OSArchitecture)" -ForegroundColor DarkCyan

# 2. Network Adapter & DNS Audit
Write-Host "[*] Auditing active network adapters and DNS servers..." -ForegroundColor Yellow
$Adapters = Get-NetAdapter | Where-Object {$_.Status -eq 'Up'}
foreach ($adapter in $Adapters) {
    $Dns = Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4
    Write-Host "    -> Adapter: $($adapter.Name) [Status: Up]" -ForegroundColor DarkCyan
    Write-Host "       DNS Servers: $($Dns.ServerAddresses -join ', ')" -ForegroundColor Gray
}

# 3. Firewall Profile Status
Write-Host "[*] Checking firewall profile enforcement..." -ForegroundColor Yellow
$Profiles = Get-NetFirewallProfile
foreach ($profile in $Profiles) {
    $State = if ($profile.Enabled) { "ENABLED" } else { "DISABLED" }
    $Color = if ($profile.Enabled) { "Green" } else { "Red" }
    Write-Host "    -> Profile ($($profile.Name)): $State [Inbound: $($profile.DefaultInboundAction), Outbound: $($profile.DefaultOutboundAction)]" -ForegroundColor $Color
}

# 4. Telemetry & Bloat Service Status
Write-Host "[*] Inspecting telemetry and diagnostic service states..." -ForegroundColor Yellow
$ServicesToCheck = @("DiagTrack", "dmwappushservice", "WerSvc")
foreach ($svcName in $ServicesToCheck) {
    $svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
    if ($svc) {
        $StatusColor = if ($svc.Status -eq 'Running') { "Yellow" } else { "Green" }
        Write-Host "    -> Service [$($svc.Name)]: Status = $($svc.Status), Startup = $($svc.StartType)" -ForegroundColor $StatusColor
    } else {
        Write-Host "    -> Service [$svcName]: Not Found / Removed" -ForegroundColor Green
    }
}

Write-Host "========================================================" -ForegroundColor Cyan
Write-Host " AUDIT COMPLETE. SYSTEM POSTURE CAPTURED." -ForegroundColor Green
Write-Host "========================================================" -ForegroundColor Cyan