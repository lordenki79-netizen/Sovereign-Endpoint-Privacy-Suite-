<#
.SYNOPSIS
    Sovereign System Scrubber & Privacy Suite (v2.0)
.DESCRIPTION
    Aggressively purges temp files, error reports, browser caches, and optionally sanitizes event logs.
#>

function Invoke-SovereignScrubber {
    [CmdletBinding()]
    param(
        [Parameter()]
        [switch]$SanitizeEventLogs
    )

    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host " INITIATING SOVEREIGN PRIVACY SYSTEM SCRUBBER v2.0" -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Cyan

    # 1. Purge OS & User Temp Files
    Write-Host "[*] Purging temporary files and update caches..." -ForegroundColor Yellow
    $TempPaths = @(
        "$env:SystemRoot\Temp\*",
        "$env:LOCALAPPDATA\Temp\*",
        "$env:SystemRoot\SoftwareDistribution\Download\*"
    )
    $TempPaths.ForEach({
        if (Test-Path $_) {
            Get-ChildItem -Path $_ -Recurse -Force -ErrorAction SilentlyContinue | 
                Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        }
    })
    Write-Host "[+] Temp directories and update caches cleared." -ForegroundColor Green

    # 2. Wipe Windows Error Reporting Dumps
    Write-Host "[*] Wiping crash dumps and error logs..." -ForegroundColor Yellow
    $WerPaths = @(
        "$env:ProgramData\Microsoft\Windows\WER\*",
        "$env:LOCALAPPDATA\Microsoft\Windows\WER\*"
    )
    $WerPaths.ForEach({
        if (Test-Path $_) {
            Get-ChildItem -Path $_ -Recurse -Force -ErrorAction SilentlyContinue | 
                Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        }
    })
    Write-Host "[+] Crash reports wiped." -ForegroundColor Green

    # 3. Purge Browser Caches (Firefox & Chromium-based)
    Write-Host "[*] Sweeping browser caches and session storage..." -ForegroundColor Yellow
    $BrowserCachePaths = @(
        "$env:LOCALAPPDATA\Mozilla\Firefox\Profiles\*\cache2\*",
        "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache\*",
        "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache\*"
    )
    $BrowserCachePaths.ForEach({
        if (Test-Path $_) {
            Get-ChildItem -Path $_ -Recurse -Force -ErrorAction SilentlyContinue | 
                Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        }
    })
    Write-Host "[+] Browser tracking caches cleared." -ForegroundColor Green

    # 4. Optional Event Log Sanitization
    if ($SanitizeEventLogs) {
        Write-Host "[!] Sanity Check: Clearing Windows Event Logs..." -ForegroundColor Red
        $EventLogs = Get-WinEvent -ListLog * -ErrorAction SilentlyContinue
        foreach ($Log in $EventLogs) {
            try {
                ([WMIClass]"root\cimv2:Win32_NTEventLogFile").Where("LogFileName='$($Log.LogName)'").ClearEventLog() | Out-Null
            } catch {
                # Silently bypass locked logs
            }
        }
        Write-Host "[+] Event logs completely sanitized." -ForegroundColor Green
    }

    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host " SYSTEM SCRUB COMPLETE. ENVIRONMENT IS HYGIENIC." -ForegroundColor Green
    Write-Host "========================================================" -ForegroundColor Cyan
}

# Run the scrubber (include -SanitizeEventLogs if you want deep log wiping)
Invoke-SovereignScrubber