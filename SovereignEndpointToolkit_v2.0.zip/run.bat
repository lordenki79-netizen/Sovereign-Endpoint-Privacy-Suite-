@echo off
powershell.exe -ExecutionPolicy Bypass -File "%~dp0SovereignMaster.ps1"