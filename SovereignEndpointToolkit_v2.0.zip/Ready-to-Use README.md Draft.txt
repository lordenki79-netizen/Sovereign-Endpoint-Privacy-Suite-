# Sovereign Endpoint & Privacy Toolkit

A high-performance, transparent PowerShell suite designed for power users, security researchers, and privacy enthusiasts who demand absolute control over their Windows environment.

## What's Included

1. **Endpoint Provisioning Engine (`ProvisioningEngine.ps1`)**
   - Hardcodes secure DNS (Quad9) to bypass ISP logging.
   - Enforces a zero-disruption firewall baseline with default-deny inbound rules.
   - Strips telemetry tasks, background diagnostics, and bloatware services.

2. **System Scrubber & Privacy Suite (`SystemScrubber.ps1`)**
   - Deep-cleans system and user temp directories.
   - Wipes Windows Error Reporting (WER) crash dumps.
   - Purges browser caching and tracking residue (Firefox & Chromium).
   - Optional deep-clean flag (`-SanitizeEventLogs`) for forensic lab hygiene.

## Usage Instructions
1. Open PowerShell as **Administrator**.
2. Run your chosen script:
   ```powershell
   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\SystemScrubber.ps1