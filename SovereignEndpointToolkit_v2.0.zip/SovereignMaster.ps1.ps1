# ======================================================================
# SOVEREIGN TOOLKIT - MASTER CONTROL PANEL
# ======================================================================

function Show-Menu {
    Clear-Host
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host "             SOVEREIGN SECURITY TOOLKIT                 " -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host "  [1] Sovereign Scout (Run System Audit & Diagnostics)" -ForegroundColor Yellow
    Write-Host "  [2] Sovereign Scrubber (Purge Temp Files & Caches)" -ForegroundColor Yellow
    Write-Host "  [3] Sovereign Provisioning Engine (Harden System)" -ForegroundColor Yellow
    Write-Host "  [4] Exit Toolkit" -ForegroundColor DarkGray
    Write-Host "========================================================" -ForegroundColor Cyan
}

do {
    Show-Menu
    $Choice = Read-Host "[?] Select an option (1-4)"

    switch ($Choice) {
        '1' {
            Write-Host "`n[*] Launching Sovereign Scout..." -ForegroundColor Green
            if (Test-Path "$PSScriptRoot\SovereignScout.ps1") {
                & "$PSScriptRoot\SovereignScout.ps1"
            } else {
                Write-Host "[!] Error: SovereignScout.ps1 not found in directory." -ForegroundColor Red
            }
            Pause
        }
        '2' {
            Write-Host "`n[*] Launching Sovereign Scrubber..." -ForegroundColor Green
            if (Test-Path "$PSScriptRoot\SystemScrubber.ps1") {
                & "$PSScriptRoot\SystemScrubber.ps1"
            } else {
                Write-Host "[!] Error: SystemScrubber.ps1 not found in directory." -ForegroundColor Red
            }
            Pause
        }
        '3' {
            Write-Host "`n[*] Launching Sovereign Provisioning Engine..." -ForegroundColor Green
            if (Test-Path "$PSScriptRoot\Deploy-SovereignBaseline.ps1") {
                & "$PSScriptRoot\Deploy-SovereignBaseline.ps1"
            } else {
                Write-Host "[!] Error: Deploy-SovereignBaseline.ps1 not found in directory." -ForegroundColor Red
            }
            Pause
        }
        '4' {
            Write-Host "`n[*] Exiting Sovereign Toolkit. Stay sovereign." -ForegroundColor Cyan
            exit
        }
        default {
            Write-Host "`n[!] Invalid selection. Please choose between 1 and 4." -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }
} while ($true)